import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
username:string="mahesh";
password:string="";
errmsg:boolean=false;
  constructor() { }

  ngOnInit() {
  }
login(){
  if(this.username==""){
   this.errmsg=true;
  }else { 
    this.errmsg=false;
   }
}
}
