import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LoginComponent} from './login/login.component'
import { TilesComponent } from './tiles/tiles.component';
import {WelcomeComponent} from './welcome/welcome.component'
import { TileDetailComponent } from './tile-detail/tile-detail.component';
import {RegisterComponent} from './users/register/register.component'

const routes: Routes = [
  {
    path:'login',component:LoginComponent
  },
  {
    path:'register',component:RegisterComponent
  },
  {
    path:'tiles',component:TilesComponent
  },
  {
    path:'tiles/:Id',component:TileDetailComponent
  },
  {
    path:'welcome',component:WelcomeComponent
  },
  {
    path:'',redirectTo:'login',pathMatch:'prefix'
  },{
    path:'**',redirectTo:'login',pathMatch:'prefix'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
