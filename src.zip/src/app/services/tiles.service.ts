import { Injectable } from '@angular/core';
import { ITile } from '../interfaces/itile';
import { HttpClient } from '@angular/common/http';
import { observable, Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class TilesService {
  private api_url:string="http://demo5911200.mockable.io/tiles";
  constructor(private httpClient:HttpClient) { }
  getTiles():Observable<Array<ITile>>{
    return this.httpClient.get<Array<ITile>>(this.api_url);
  }
  getTileDetails(tileId:number):Observable<ITile>{
    return this.httpClient.get<ITile>(this.api_url+`/${tileId}`);
  }
  
}
