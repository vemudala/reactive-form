import { Component, OnInit, Input, OnChanges, Output, EventEmitter } from '@angular/core';
// import { EventEmitter } from 'events';

@Component({
  selector: 'app-star',
  templateUrl: './star.component.html',
  styleUrls: ['./star.component.css']
})
export class StarComponent implements OnInit , OnChanges{
@Input() rating:number=0;
ratingArray:Array<number>=[] ; //@ for displaying number of stars
newRating:string="" ;
// @Output() ratingUpdated:EventEmitter<string>=new EventEmitter(); //method 1 for output binidng
@Output() ratingUpdated = new EventEmitter<{newRating:string}>(); //method 2 for output binidng
constructor() {
    
   }

  ngOnInit() { // console.log(this.rating);
  }
ngOnChanges():void{
  console.log(this.rating);
  for(let index=0; index<this.rating; index++){
    this.ratingArray.push(index);
  }
}
updateRating(){
  console.log(this.newRating);
  // this.ratingUpdated.emit(this.newRating) // //method 1 for output binidng
    this.ratingUpdated.emit({newRating:this.newRating}) // //method 2 for output binidng
  
}
}
