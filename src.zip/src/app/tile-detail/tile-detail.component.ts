import { Component, OnInit } from '@angular/core';
import { ITile } from '../interfaces/itile';
import { ActivatedRoute , Router} from '@angular/router';
import { TilesService } from '../services/tiles.service';

@Component({
  selector: 'app-tile-detail',
  templateUrl: './tile-detail.component.html',
  styleUrls: ['./tile-detail.component.css']
})
export class TileDetailComponent implements OnInit {
tile:ITile; 

imagePath:string= '/assets/images/';
tileId:number;
  constructor(private activatedRoute:ActivatedRoute, private tileService:TilesService,private router:Router) { 
    this.tileId= +this.activatedRoute.snapshot.paramMap.get('Id'); //+ added bcz  here this.tileId expecting number but its value assigned as string here we make string to number by using + sign
  console.log(this.tileId);
  }

  ngOnInit() {
    this.tileService.getTileDetails(this.tileId).subscribe((tile)=>{
this.tile=tile; 
    })

  }
  navigateBack():void{
    this.router.navigate(['/tiles']);

  }
}
