export interface ITile {
    name:string;
    model:string;
    price:number;
    rating:number;
    image:string;
    status:number;
    Id:number;
}
